﻿// validates form elemensts
// and provides help prompts
// Developer:  Stuart Stevenson
//
	function ajaxPost(strURL, strParms, targetId, targetType) {
    var xmlHttpReq = false;
    var response = '';
    // Mozilla/Safari
    if (window.XMLHttpRequest) {
        xmlHttpReq = new XMLHttpRequest();
    }
    // IE
    else if (window.ActiveXObject) {
        xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlHttpReq.open('POST', strURL, true);
    xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xmlHttpReq.onreadystatechange = function() {
        if (xmlHttpReq.readyState == 4) {
            response = xmlHttpReq.responseText;
            response=checkScript(response);
            switch (targetType) {
                case 'html':
                    document.getElementById(targetId).innerHTML=response;
                    break;
                case 'val':
                    document.getElementById(targetId).value=response;
                    break;
                case 'fn':
                    eval(targetId+'(response);');
                    break;
                case 'fnP':
                    eval(targetId+',response);');
                    break;
                case 'var':
                    eval(targetId+'="'+response+'";');
                    break;
                default:
                    return response;
            }
        }
    }
		var cacheCtrl = new Date();
		strParms+='&nochache='+cacheCtrl.toString();
    xmlHttpReq.send(strParms);
	}
	
	function checkScript(sRtn) {
	    var nS = sRtn.indexOf('<scr'+'ipt');
	    var nE = sRtn.indexOf('</scr'+'ipt');
	    if (nS>=0 && nE>=0) {
	        var sScript=sRtn.substring(nS+8,nE);
	        sRtn=sRtn.substring(0,nS)+sRtn.substring(nE+9);
	        var el=document.getElementById('testblock');
	        // if (el) el.innerHTML=sScript;
	        eval(sScript);
	    }
	    return sRtn;
	}

	/* --- moves focus to the active field --- */
	function setActiveFld(fld) {
		activeFld=fld;
		document.getElementById('activeFldDiv').innerHTML=activeFld;
	}

	function setFocus(ctrl) {
		if (ctrl==null) return;
		setTimeout(function(){ctrl.focus()}, 100);
		setActiveFld(ctrl.name);
	}
	

	/* --- auto complete ssn --- */
	function ssnFix(ctrl) {
		if (activeFld!=ctrl.name) return;
		clearHelp();
		var thisVal = removeNonDigits(ctrl.value);
		if (thisVal.length==9) {
			// check for existing value...
			if (!ctrl.id) ctrl.id=ctrl.name;
			ajaxPost('SSNCheckAjax.asp', 'SSN='+thisVal, 'ssnPost('+ctrl.id, 'fnP');
			ctrl.value=thisVal.substr(0,3)+'-'+thisVal.substr(3,2)+'-'+thisVal.substr(5,4);
		} else {
			ctrl.select();
			showTip(ctrl,'Please enter a social security number in xxx-xx-xxxx format.');
			setFocus(ctrl);
			return false;
		}
	}

	/* --- dup ssn --- */
	function ssnPost(ctrlID,rtnValue) {
		var ctrl=document.getElementById(ctrlID);
		switch(rtnValue) {
			case '1':
				errorBeep();
				clearHelp();
				ctrl.select();
				setFocus(ctrl);
				showTip(ctrl,'That SSN is already used by another subscriber');
				return false;
				break;
			case '2':
				errorBeep();
				clearHelp();
				ctrl.select();
				setFocus(ctrl);
				showTip(ctrl,'That SSN is already used by another dependent');
				return false;
				break;
		}
	}				
			
	/* --- auto complete phone --- */
	function phoneFix(ctrl,required) {
		if (activeFld!=ctrl.name) return;
		clearHelp();
		var thisVal = removeNonDigits(ctrl.value);
		if (thisVal.length==11 && thisVal.substr(0,1)==1) {
			thisVal=thisVal.substr(1);
		}
		if (thisVal.length==10) {
			ctrl.value=thisVal.substr(0,3)+'-'+thisVal.substr(3,3)+'-'+thisVal.substr(6,4);
		} else {
			if (required || ctrl.value.length) {
				errorBeep();
				ctrl.select();
				setFocus(ctrl);
				showTip(ctrl,'Please enter 10 digits.');
				return false;
			}
		}
	}

  /* --- prompts to select a value when null --- */
  function selectFix(ctrl,required) {
		if (activeFld!=ctrl.name) return;
		clearHelp();
		if (required && ctrl.value.length<1) {
			errorBeep();
			setFocus(ctrl);
			showTip(ctrl,'Please select a value.');
			return false;
		}
	}

	/* fixes zip codes */		  	
	function zipFix(ctrl,required) {
		if (activeFld!=ctrl.name) return;
		clearHelp();
		var thisVal = removeNonDigits(ctrl.value);
		if (thisVal.length==5 || thisVal.length==9) {
			ctrl.value=thisVal.substr(0,5);
			if (thisVal.length>5) ctrl.value+='-'+thisVal.substr(5);
		} else {
			if (required || ctrl.value.length) {
				errorBeep();
				ctrl.select();
				setFocus(ctrl);
				showTip(ctrl,'Please enter 5 or 9 digits.');
				return false;
			}
		}
	}
	
	/* fixes email addresses */
	function emailFix(ctrl,required){
		if (activeFld!=ctrl.name) return;
		clearHelp();
		var status = false;     
		var emailRegEx = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
    if (ctrl.value.search(emailRegEx) == -1) {
			if (required || ctrl.value.length) {
				errorBeep();
				ctrl.select();
				setFocus(ctrl);
				showTip(ctrl,'Please enter a valid email address.');
				return false;
			}
		}
	}
	
	/* --- prompt for data in text element --- */
	function textFix(ctrl,text) {
		if (activeFld!=ctrl.name) return;
		clearHelp();
		if (!ctrl.value.length) {
			errorBeep();
			ctrl.select();
			setFocus(ctrl);
			showTip(ctrl,text);
			return false;
		}
	}
		
	/* --- auto complete dates --- */	
	function dateFix(ctrl,required){
		var checkstr = "0123456789";
		var DateField = ctrl;
		var DateValue = "";
		var DateTemp = "";
		var seperator = "/";
		var centuryRollover = 30;
		var day;
		var month;
		var year;
		var leap = 0;
		var err = 0;
		var i;
	  err = 0;

		if (activeFld!=ctrl.name) return;
		clearHelp();
	  
	  DateValue = DateField.value;
	  /* replace - or , or . formatters with /  */
	  DateValue=DateValue.replace('-','/');
	  DateValue=DateValue.replace('.','/');
	  DateValue=DateValue.replace(',','/');

	  /* see if we have 2 digits before and between / if formatted */
	  if (DateValue.indexOf('/')==1) {
	  	DateValue='0'+DateValue;
	  }
	  if (DateValue.lastIndexOf('/')==4) {
	  	DateValue=DateValue.substr(0,3)+'0'+DateValue.substr(3);
	  }
	  
	  /* Delete all chars except 0..9 */
	  for (i = 0; i < DateValue.length; i++) {
		  if (checkstr.indexOf(DateValue.substr(i,1)) >= 0) {
		     DateTemp = DateTemp + DateValue.substr(i,1);
		  }
	  }
	  DateValue = DateTemp;
	  
	  /* Always change date to 8 digits - string*/
	  /* if year is entered as 2-digit / always assume 20xx */
	  if (DateValue.length == 6) {
	    year = DateValue.substr(4,2);
	    if(year>centuryRollover) {
		    DateValue = DateValue.substr(0,4) + '19' + DateValue.substr(4,2); 
		  } else {
	    	DateValue = DateValue.substr(0,4) + '20' + DateValue.substr(4,2); 
	    }
	  }
	  if (DateValue.length != 8) {
	    err = 19;}
	  
	  /* year is wrong if year = 0000 */
	  year = DateValue.substr(4,4);
	  if (year == 0) {
	    err = 20;
	  }
	  
	  /* Validation of month*/
	  month = DateValue.substr(0,2);
	  if ((month < 1) || (month > 12)) {
	    err = 21;
	  }
	  
	  /* Validation of day*/
	  day = DateValue.substr(2,2);
	  if (day < 1) {
	    err = 22;
	  }
	  
	  /* Validation leap-year / february / day */
	  if ((year % 4 == 0) || (year % 100 == 0) || (year % 400 == 0)) {
	  	leap = 1;
	  }
	  if ((month == 2) && (leap == 1) && (day > 29)) {
	    err = 23;
	  }
	  if ((month == 2) && (leap != 1) && (day > 28)) {
	    err = 24;
	  }
	  /* Validation of other months */
	  if ((day > 31) && ((month == "01") || (month == "03") || (month == "05") || (month == "07") || (month == "08") || (month == "10") || (month == "12"))) {
	    err = 25;
	  }
	  if ((day > 30) && ((month == "04") || (month == "06") || (month == "09") || (month == "11"))) {
	    err = 26;
	  }
	  
	  /* if 00 ist entered, no error, deleting the entry */
	  if ((day == 0) && (month == 0) && (year == 00)) {
	    err = 27; day = ""; month = ""; year = ""; seperator = "";
	  }
	  
	  /* if no error, write the completed date to Input-Field (e.g. 12.13.2001) */
	  if (err == 0) {
	    DateField.value = month + seperator + day + seperator + year;
	  }
	  	/* Error-message if err != 0 */
	  else {
	  	if(required || DateField.value.length) {
				errorBeep();
				if (true || DateField.value.length>0 || DateValue.length>0) {
					ctrl.select();
					setFocus(ctrl);
					showTip(ctrl,'Please enter a date in mm/dd/yyyy format.');
					return false;
				}
			}
	   }
	}
	
	/* help propmt functions */	
	function dateFld(ctrl) {
		if (activeFld.length) return;
		document.getElementById('helpPrompt').innerHTML="Enter date with these formats:&nbsp;m/d/yy, mm/dd/yyyy, mmddyy, mmddyyyy. "
		                +"Use dashes, dots or slashes as separators.";
		setActiveFld(ctrl.name);
	}
	function ssnFld(ctrl) {
		if (activeFld.length) return;
		document.getElementById('helpPrompt').innerHTML="You may enter social security numbers with or without dashes.";
		setActiveFld(ctrl.name);
	}
	function textFld(ctrl,desc) {
		if (activeFld.length) return;
		document.getElementById('helpPrompt').innerHTML="Please enter a "+desc + ".";
		setActiveFld(ctrl.name);
	}
	function phoneFld(ctrl) {
		if (activeFld.length) return;
		document.getElementById('helpPrompt').innerHTML="Phone numbers must include the area code in this format:&nbsp;&nbsp;214-555-1212<br>";
		setActiveFld(ctrl.name);
	}
	function zipFld(ctrl) {
		if (activeFld.length) return;
		document.getElementById('helpPrompt').innerHTML="Enter a 5 or 9 digit zip code.";
		setActiveFld(ctrl.name);
	}
	function selectFld(ctrl,desc) {
		if (activeFld.length) return;
		document.getElementById('helpPrompt').innerHTML="Please select "+desc+".";
		setActiveFld(ctrl.name);
	}
	function clearHelp() {
		document.getElementById('helpPrompt').innerHTML="";
		setActiveFld('');
		hideTip();
		//clearMsg();
	}
	
	function errorBeep() {
	// var sound = document.getElementById('errorBeepObj');
  	// if (sound) sound.Play();
	}
	
	/* --- removes non-numeric values --- */
	function removeNonDigits(num) {
		var cln = num.replace(/[^\d]/g, '');
		return cln
	}
	
	function isDate(s) {  
  	// make sure it is in the expected format
  	if (s.search(/^\d{1,2}[\/|\-|\.|_]\d{1,2}[\/|\-|\.|_]\d{4}/g) != 0)
     return false;
 
  	// remove other separators that are not valid with the Date class   
  	s = s.replace(/[\-|\.|_]/g, "/");
 
  	// convert it into a date instance
  	var dt = new Date(Date.parse(s));    
 
  	// check the components of the date
  	// since Date instance automatically rolls over each component
  	var arrDateParts = s.split("/");
     	return (
      	  dt.getMonth() == arrDateParts[0]-1 &&
        	dt.getDate() == arrDateParts[1] &&
         	dt.getFullYear() == arrDateParts[2]
     );  
	}	

