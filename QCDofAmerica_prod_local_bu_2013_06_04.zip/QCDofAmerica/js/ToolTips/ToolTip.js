var qTipTag = ""; //Which tags do you want to automatically qTip-ize? Keep it lowercase!//
var qTipX = 40; //This is qTip's X offset from target element//
var qTipY = -22; //This is qTip's Y offset from target element//
var qFollowMouse = false;

//There's no need to edit anything below this line//
tooltip = {
  name : "qTip",
  offsetX : qTipX,
  offsetY : qTipY,
  followMouse : qFollowMouse,
  tip : null
}

tooltip.init = function () {
	var tipNameSpaceURI = "http://www.w3.org/1999/xhtml";
	if(!tipContainerID){ var tipContainerID = "qTip";}
	var tipContainer = document.getElementById(tipContainerID);

	if(!tipContainer) {
	  tipContainer = document.createElementNS ? document.createElementNS(tipNameSpaceURI, "div") : document.createElement("div");
		tipContainer.setAttribute("id", tipContainerID);
	  document.getElementsByTagName("body").item(0).appendChild(tipContainer);
	}

	if (!document.getElementById) return;
	this.tip = document.getElementById (this.name);
	// if followMouse is true tips to follow mouse. Otherwise, they
	// will be positioned relative to a control (input fld, etc.)
	if (this.followMouse && this.tip) document.onmousemove = function (evt) {tooltip.move (evt)};

	var a, sTitle, elements;
	
	// automatic tips for tag types
	if (qTipTag.length) {
		var elementList = qTipTag.split(",");
		for(var j = 0; j < elementList.length; j++)
		{	
			elements = document.getElementsByTagName(elementList[j]);
			if(elements)
			{
				for (var i = 0; i < elements.length; i ++)
				{
					a = elements[i];
					sTitle = a.getAttribute("title");				
					if(sTitle)
					{
						a.setAttribute("tiptitle", sTitle);
						a.removeAttribute("title");
						a.removeAttribute("alt");
						a.onmouseover = function() {tooltip.show(this,this.getAttribute('tiptitle'))};
						a.onmouseout = function() {tooltip.hide()};
					}
				}
			}
		}
	}
}

tooltip.move = function (evt) {
	var x=0, y=0;
	if (document.all) {//IE
		x = (document.documentElement && document.documentElement.scrollLeft) ? document.documentElement.scrollLeft : document.body.scrollLeft;
		y = (document.documentElement && document.documentElement.scrollTop) ? document.documentElement.scrollTop : document.body.scrollTop;
		x += window.event.clientX;
		y += window.event.clientY;
		
	} else {//Good Browsers
		x = evt.pageX;
		y = evt.pageY;
	}
	this.tip.style.left = (x + this.offsetX) + "px";
	this.tip.style.top = (y + this.offsetY) + "px";
}

tooltip.show = function (ctrl, text) {
	if (!this.tip) {return; }
	if (!this.followMouse) {
		var curPos = findPos(ctrl);
		this.tip.style.left = (curPos[0]+this.offsetX)+'px';
		this.tip.style.top = (curPos[1]+this.offsetY)+'px';
	}
	this.tip.innerHTML = text;
	this.tip.style.display = "block";
}

tooltip.hide = function () {
	if (!this.tip) return;
	this.tip.innerHTML = "";
	this.tip.style.display = "none";
}

// Multiple onload function created by: Simon Willison
// http://simonwillison.net/2004/May/26/addLoadEvent/
function addLoadEvent(func) {
  var oldonload = window.onload;
  if (typeof window.onload != 'function') {
    window.onload = func;
  } else {
    window.onload = function() {
      if (oldonload) {
        oldonload();
      }
      func();
    }
  }
}

addLoadEvent(function() {
  tooltip.init ();
});

function setTipOnFocus(ctrlID) {
	var a = document.getElementById(ctrlID);
	sTitle = a.getAttribute("title");				
	if(sTitle)
		{
			a.setAttribute("tiptitle", sTitle);
			a.removeAttribute("title");
			a.removeAttribute("alt");
			a.onfocus = function() {tooltip.show(this, this.getAttribute('tiptitle'))};
			a.onblur = function() {tooltip.hide()};
		}
}	
function setTipOnMouseover(ctrlID) {
	var a = document.getElementById(ctrlID);
	sTitle = a.getAttribute("title");				
	if(sTitle)
		{
			a.setAttribute("tiptitle", sTitle);
			a.removeAttribute("title");
			a.removeAttribute("alt");
			a.onmouseover = function() {tooltip.show(this, this.getAttribute('tiptitle'))};
			a.onmouseout = function() {tooltip.hide()};
		}
}	
function showTip(ctrlID,sTitle) {
	if (typeof ctrlID=="object") {
		var a=ctrlID;
	} else {
		var a=document.getElementById(ctrlID);
	}
	if(!sTitle) sTitle = a.getAttribute("title");				
	if(!sTitle) sTitle = a.getAttribute("tiptitle");				
	if(sTitle) {
		tooltip.show(a,sTitle);
	} 
}
function hideTip() {
	tooltip.hide();
}
	
function findPos(obj) {
	var curleft = curtop = 0;
	if (obj.offsetParent) {
		do {
			curleft += obj.offsetLeft;
			curtop += obj.offsetTop;
		} while (obj = obj.offsetParent);
	}
	return [curleft,curtop];
}

