//------------------------------------
//
//   Functions to run the slider on home page
//   Function Names:
//                         mycarousel_initcallback
//
//
//------------------------------------

$(function() {
	$('.field, textarea').focus(function() {
        if(this.title==this.value) {
            this.value = '';
        }
    }).blur(function(){
        if(this.value=='') {
            this.value = this.title;
        }
    });

    $("#slider ul.slides").jcarousel({
        visible: 1,
        wrap: 'both',
        auto: 5,
        scroll: 1,
        initCallback: mycarousel_initCallback,
        itemVisibleInCallback: {
            onAfterAnimation: function(c, o, i, s) {
                $('.slider-nav a').removeClass('active');
                $('.slider-nav a:eq('+ (i-1) +')').addClass('active');
            }
        },
        buttonNextHTML: null,
        buttonPrevHTML: null
    });

    if ($.browser.msie && $.browser.version == 6) {
		DD_belatedPNG.fix('.banner img, .slide-1 img');
	}
});

function mycarousel_initCallback(carousel) {
    $('.slider-nav a').bind('click', function() {
        carousel.scroll($.jcarousel.intval($(this).text()));
        return false;
	});
};

//----------------------------------------
//  Functions for inactivity timeout
//
//
//----------------------------------------

	// Add the following into your HEAD section
	var timer = 0;
	function set_interval() 
	{
	  // the interval 'timer' is set as soon as the page loads
	  timer = setInterval("warnuser()", 1*60*1000);  // 10 Minutes
	  // the figure '10000' above indicates how many milliseconds the timer be set to.
	  // Eg: to set it to 5 mins, calculate 5min = 5x60 = 300 sec = 300,000 millisec.
	  // So set it to 300000
	}

	function reset_interval() 
	{
	  //resets the timer. The timer is reset on each of the below events:
	  // 1. mousemove   2. mouseclick   3. key press 4. scroliing
	  //first step: clear the existing timer
	
		  if (timer != 0) 
		  {
		    clearInterval(timer);
		    timer = 0;
		    // second step: implement the timer again
		    timer = setInterval("warnuser()", 1*60*1000);   // 10 Minutes
		    // completed the reset of the timer
		  }
	}

