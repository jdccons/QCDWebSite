vti_encoding:SR|utf8-nl
vti_timelastmodified:TW|02 Jan 2013 17:38:32 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|John-Lat_E6510\\John
vti_modifiedby:SR|John-Lat_E6510\\John
vti_timecreated:TR|30 Apr 2012 11:59:29 -0000
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|02 Jan 2013 17:38:32 -0000
vti_cacheddtm:TX|30 May 2013 14:22:21 -0000
vti_filesize:IR|17266
vti_syncwith_www.qcdofamerica.com\:21:TW|30 May 2013 14:22:21 -0000
vti_syncofs_www.qcdofamerica.com\:21:TW|02 Jan 2013 17:38:32 -0000
