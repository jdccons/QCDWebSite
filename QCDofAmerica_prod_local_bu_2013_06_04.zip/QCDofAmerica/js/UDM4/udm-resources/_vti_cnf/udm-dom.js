vti_encoding:SR|utf8-nl
vti_timelastmodified:TW|02 Jan 2013 17:38:48 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|ssi/nav.htm ssi/ssi-nav-admin.asp ssi/ssi-nav.asp templates/nav.html js/UDM4/template.html ssi/ssi-nav.htm
vti_author:SR|John-Lat_E6510\\John
vti_modifiedby:SR|John-Lat_E6510\\John
vti_timecreated:TR|30 Apr 2012 11:59:29 -0000
vti_nexttolasttimemodified:TW|02 Jan 2013 17:38:48 -0000
vti_cacheddtm:TX|30 May 2013 14:22:21 -0000
vti_filesize:IR|21984
vti_syncwith_www.qcdofamerica.com\:21:TW|30 May 2013 14:22:21 -0000
vti_syncofs_www.qcdofamerica.com\:21:TW|02 Jan 2013 17:38:48 -0000
