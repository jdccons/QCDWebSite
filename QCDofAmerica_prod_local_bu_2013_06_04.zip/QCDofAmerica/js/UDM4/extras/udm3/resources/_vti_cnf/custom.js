vti_encoding:SR|utf8-nl
vti_timelastmodified:TW|30 Apr 2012 11:35:51 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|js/UDM4/extras/udm3/template.html
vti_author:SR|John-Lat_E6510\\John
vti_modifiedby:SR|John-Lat_E6510\\John
vti_timecreated:TR|30 Apr 2012 11:59:28 -0000
vti_nexttolasttimemodified:TW|30 Apr 2012 11:35:51 -0000
vti_cacheddtm:TX|30 Apr 2012 11:59:28 -0000
vti_filesize:IR|13868
vti_syncwith_www.qcdofamerica.com\:21:TW|30 Apr 2012 11:59:28 -0000
vti_syncofs_www.qcdofamerica.com\:21:TW|30 Apr 2012 11:35:51 -0000
