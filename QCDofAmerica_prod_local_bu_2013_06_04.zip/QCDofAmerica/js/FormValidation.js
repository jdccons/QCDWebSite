//JavaScript Document

///////////////////////////////////////////////////////////////////////////
//
//  Programmer:  John Criswell
//  Date Created:  01/13/2009
//  Date Modified:  01/17/2009
//  Modificaiton History:
//                  01/17/2009 - added a new validate_date function  
//  
//  Purpose:  This is a library of general purpose JavaScript functions
//            used for form validation.
//  List of functions:
//                        1. validate_phone(field, alerttext) 
//                        2. validate_required(field, alerttext) 
//                        3. 
//                        4. validate_zip(field, alerttext)
//                        5. validateZIP(input, alerttext)
//                        6. validate_email(field, alerttext)
//                        7. validate_state(field, alerttext)
//                        7. validate_planid(field, alerttext)
//                        8. validate_coverid(field, alerttext)                        
//                        9. validate_gender(field, alerttext)
//                        10. validate_marital_status(field, alerttext)
//                            validate_employment_status(field, alerttext)
//                        11. validate_dropdown(field, alerttext)
//                        12. isInteger(s)
//                        13. validate_social_security(field, alerttext)
//                        14. allDigits(str)
//                        15. inValidChrSet(str)
//                        17. calcAge(value)
//                        18. phoneDigits(str)
//                        19. ifPresent(field)                       
///////////////////////////////////////////////////////////////////////////

String.prototype.trim = function() {
	return this.replace(/^\s+|\s+$/g,"");
}
String.prototype.ltrim = function() {
	return this.replace(/^\s+/,"");
}
String.prototype.rtrim = function() {
	return this.replace(/\s+$/,"");
}	
	
//<--- validate phone start
function validate_phone(field, alerttext)
{
with (field)
{
   var result = true;
   if (value==null||value=="")
   {
  		alert(alerttext);
  		result = false;
   }
   else if(value.search(/\d{3}\-\d{3}\-\d{4}/)==-1)
   {
      	alert("The phone number you entered is not valid.\r\nPlease enter a phone number with the format xxx-xxx-xxxx.");
      	result = false;
   }
   	return result;
}
}
//<--- validate phone end here


//<--- validate required start here
function validate_required(field, alerttext)
{
with (field)
{
  if (value==null||value=="")
  {
  	alert(alerttext);
  	return false;
  }
  else
  {
  	return true;
  }
}
}
//<---   validate require end here
	
	
//<---   validate zip start here
function validate_zip(field, alerttext)
{
with (field)
{
	{
	var result = true;
	result = validateZIP(value, "");
	return result;
	}
}
}
//<---    validate zip end here


//----------------------------------------------
function validateZIP(input, alerttext) 
{
	var valid = "0123456789-";
	var hyphencount = 0;
	input = input.trim();
	
	if (input.length!=5 && input.length!=10) 
	{
		alert("Please enter your 5 digit or 5 digit+4 zip code.");
		return false;
	}
	for (var i=0; i < input.length; i++) 
	{
	temp = "" + input.substring(i, i+1);
	if (temp == "-") hyphencount++;
	if (valid.indexOf(temp) == "-1") 
	{
		alert("Invalid characters in your zip code.  Please try again.");
		return false;
	}
	if ((hyphencount > 1) || ((input.length==10) && ""+input.charAt(5)!="-")) 
	{
		alert("The hyphen character should be used with a properly formatted 5 digit+four zip code, like '12345-6789'.   Please try again.");
		return false;
    }
}
	return true;
}
//----------------------------------------------


//----------------------------------------------

//function validate_email(field, alerttext)
//{
//with (field)
//	{
//		var result = true;
//		var apos=value.indexOf("@");
//		var dotpos=value.lastIndexOf(".");
//		if (apos<1||dotpos-apos<2)
//  	 	{
//			alert("You have entered an email address in the incorrect format.  You must have an @ sign and a period!");
//			result = false;
//		}
//		else if (value==null||value=="")
//  		{
//    		result =  true;
//  		}
//				return result;
//	}
//}

//----------------------------------------------

//------------------------------------------------
function validate_email(field, alerttext){
		with (field){

		var at="@"
		var dot="."
		var lat=value.indexOf(at)
		var lstr=value.length
		var ldot=value.indexOf(dot)
		
		if (value==null||value==""){
		 		return true
		 	}
		 	
		if (value.indexOf(at)==-1){
		   alert(alerttext)
		   return false
		}

		if (value.indexOf(at)==-1 || value.indexOf(at)==0 || value.indexOf(at)==lstr){
		   alert(alerttext)
		   return false
		}

		if (value.indexOf(dot)==-1 || value.indexOf(dot)==0 || value.indexOf(dot)==lstr){
		    alert(alerttext)
		    return false
		}

		 if (value.indexOf(at,(lat+1))!=-1){
		    alert(alerttext)
		    return false
		 }

		 if (value.substring(lat-1,lat)==dot || value.substring(lat+1,lat+2)==dot){
		    alert(alerttext)
		    return false
		 }

		 if (value.indexOf(dot,(lat+2))==-1){
		    alert(alerttext)
		    return false
		 }
		
		 if (value.indexOf(" ")!=-1){
		    alert(alerttext)
		    return false
		 }
		 
	}	 

 		 return true					
	}
//------------------------------------------------

//<--- validate state start
function validate_state(field, alerttext)
{
	with (field)
	{
	var result = true;
	if (value==null||value=="")
  	{
  	alert(alerttext);
  	result = false;
  	}
	
	var sState = value;
	sState = sState.toUpperCase();
	var sStates;
	sStates = "WA|OR|CA|AK|NV|ID|UT|AZ|HI|MT|WY|" +
					"CO|NM|ND|SD|NE|KS|OK|TX|MN|IA|MO|" +
					"AR|LA|WI|IL|MS|MI|IN|KY|TN|AL|FL|" +
					"GA|SC|NC|OH|WV|VA|PA|NY|VT|ME|NH|" +
					"MA|RI|CT|NJ|DE|MD|DC";
	var iResult = sStates.indexOf(sState);
	
	if (iResult > -1)
	{
		return result;
	}
	else
	{
		alert(alerttext);
		result = false;
	}
}			
}
//<--- validate state end

//<---   validate plan ID start
function validate_planid(field, alerttext)
{
  with (field)
  {
  var result = true;
	
	if (value==null || value=="")
  {		
		alert("You must populate the Plan field!");
		result=false;
	}
	else
	
	switch (value)
	{
	case "QCD Only":
  break;
		
	case "Red":
  break;
		
	case "White":
  break;
		
	case "Blue":
  break;
	
	case "Red Plus":
  break;
		
	default:
	result=false;
	alert(alerttext);
	break;
	}
	return result;
  }
}
//<--- validate plan ID end

//----------------------------------------------
function validate_coverid(field, alerttext)
{
	with (field)
	{
		var CoverID = value;
	
		switch (CoverID)
		{
		case "Employee Only":
   			return true;
			break;
		
		case "Employee Plus One":
  			return true;
			break;
		
		case "Employee Plus Children":
  			return true;
			break;
		
		case "Employee Plus Family":
   			return true;
			break;
		
		default:
			alert(alerttext);
  			return false;
			break;
		}
	}
}
//----------------------------------------------

//----------------------------------------------
function validate_gender(field, alerttext)
{
	with (field)
	{
		var Gender = value;
	
		switch (Gender)
		{
		case "Male":
   			return true;
			break;
		
		case "Female":
  			return true;
			break;
		
		default:
			alert(alerttext);
  			return false;
			break;
		}
	}
}
//----------------------------------------------


//----------------------------------------------
function validate_marital_status(field, alerttext)
{
	with (field)
	{
		var Marital_Status = value;
	
		switch (Marital_Status)
		{
		case "M":
   			return true;
			break;
		
		case "S":
  			return true;
			break;
		
		case "U":
  			return true;
			break;
			
		default:
			alert(alerttext);
  			return false;
			break;
		}
	}
}

//----------------------------------------------

//----------------------------------------------
function validate_employment_status(field, alerttext)
{
	with (field)
	{
		var Employment_Status = value;
	
		switch (Employment_Status)
		{
		case "Active":
   			return true;
			break;
		
		case "Inactive":
  			return true;
			break;
		
		default:
			alert(alerttext);
  			return false;
			break;
		}
	}
}

//----------------------------------------------

//----------------------------------------------
function validate_dropdown(field, alerttext)
{
	with (field)
	{
		var result = true;
		if (field.selectedIndex == 0)
		{
			alert(alerttext);
			result = false;
		}
		return result;
	}
}
//----------------------------------------------

//----------------------------------------------
function validate_social_security(field, alerttext)
{
	with (field)
	{
		var result = true;
		if (value==null||value=="")
  		{
  			alert(alerttext);
  			result = false;
  		}

		else if (result)
		{
 			var elems = value.split("-");
      	// should be three components
 			result = (elems.length == 3 && elems[0].length==3 && elems[1].length==2 && elems[2].length==4);
		}
      if (result) 
	  {
      	result = allDigits(elems[0]) && allDigits(elems[1]) && allDigits(elems[2]);
      }
		   if (!result) 
		   {
		    alert("Invalid characters; you must enter 0-9 and hyphens!");
       		result = false;
           }
	    	return result;	
	}
}
//----------------------------------------------

//----------------------------------------------
function allDigits(str)
{
	return inValidCharSet(str,"0123456789-");
}
//----------------------------------------------

//----------------------------------------------
function inValidCharSet(str,charset)
{
	var result = true;

	// Note: doesn't use regular expressions to avoid early Mac browser bugs
	for (var i=0;i<str.length;i++)
		if (charset.indexOf(str.charAt(i))<0)
		{
            result = false;
			break;
		}

	return result;
}
//----------------------------------------------

//----------------------------------------------
function calcAge(sInputDate) 
{
	
	//var dateString = value;
	var today = new Date();
	var yearNow = today.getFullYear();
    var dob = new Date(sInputDate);
    var yearDob = dob.getFullYear();
    var age = yearNow - yearDob;
    var newAge;
    //return yearAge
	
	if (today.getMonth() < dob.getMonth())
	{
	newAge = age-1; 
	}
	else if (today.getMonth() == dob.getMonth() && today.getDate() < dob.getDate())
	{
	newAge = age-1;
	}
	else  
	{  
	newAge = age;  
	}
	return newAge; 
}
//----------------------------------------------

function phoneDigits(str)
{
	return inValidCharSet(str,"()- 0123456789");
}
//----------------------------------------------

//----------------------------------------------
function ifPresent(field)
{
	with (field)
	{
		var result = true;
	
		if (field.value != "") 
		{
			result = false;
		}
	return result;
	}
}

//----------------------------------------------

