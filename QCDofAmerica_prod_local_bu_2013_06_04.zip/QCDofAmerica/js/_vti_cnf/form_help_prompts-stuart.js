vti_encoding:SR|utf8-nl
vti_timelastmodified:TW|14 May 2013 17:07:48 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|John-Lat_E6510\\John
vti_modifiedby:SR|John-Lat_E6510\\John
vti_timecreated:TR|30 Apr 2012 11:59:11 -0000
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|14 May 2013 17:07:48 -0000
vti_syncwith_www.qcdofamerica.com\:21:TW|14 May 2013 17:07:09 -0000
vti_syncofs_www.qcdofamerica.com\:21:TW|14 May 2013 17:07:48 -0000
vti_cacheddtm:TX|14 May 2013 17:07:09 -0000
vti_filesize:IR|10599
