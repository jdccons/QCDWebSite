vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|31 May 2013 02:05:26 -0000
vti_author:SR|John-Lat_E6510\\John
vti_modifiedby:SR|John-Lat_E6510\\John
vti_nexttolasttimemodified:TW|02 Jan 2013 17:38:00 -0000
vti_timecreated:TR|25 May 2013 12:33:19 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|
vti_syncwith_www.qcdofamerica.com\:21:TW|25 May 2013 12:33:19 -0000
vti_syncofs_www.qcdofamerica.com\:21:TW|02 Jan 2013 17:38:00 -0000
vti_cacheddtm:TX|31 May 2013 02:05:26 -0000
vti_filesize:IR|5525
