vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Apr 2012 11:59:38 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|John-Lat_E6510\\John
vti_modifiedby:SR|John-Lat_E6510\\John
vti_timecreated:TR|30 Apr 2012 11:59:38 -0000
vti_cacheddtm:TX|30 Apr 2012 11:59:38 -0000
vti_filesize:IR|9759
vti_backlinkinfo:VX|mediaplayer/readme.html
